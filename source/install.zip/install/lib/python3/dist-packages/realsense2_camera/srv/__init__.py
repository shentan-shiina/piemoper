from ._DeviceInfo import *
