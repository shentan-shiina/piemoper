// Auto-generated. Do not edit!

// (in-package data_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TeleopStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.topics = null;
      this.fail = null;
      this.quit = null;
    }
    else {
      if (initObj.hasOwnProperty('topics')) {
        this.topics = initObj.topics
      }
      else {
        this.topics = [];
      }
      if (initObj.hasOwnProperty('fail')) {
        this.fail = initObj.fail
      }
      else {
        this.fail = false;
      }
      if (initObj.hasOwnProperty('quit')) {
        this.quit = initObj.quit
      }
      else {
        this.quit = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TeleopStatus
    // Serialize message field [topics]
    bufferOffset = _arraySerializer.string(obj.topics, buffer, bufferOffset, null);
    // Serialize message field [fail]
    bufferOffset = _serializer.bool(obj.fail, buffer, bufferOffset);
    // Serialize message field [quit]
    bufferOffset = _serializer.bool(obj.quit, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TeleopStatus
    let len;
    let data = new TeleopStatus(null);
    // Deserialize message field [topics]
    data.topics = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [fail]
    data.fail = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [quit]
    data.quit = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.topics.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'data_msgs/TeleopStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6b0691d0e673cf044908596c4b2679aa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] topics
    bool fail
    bool quit
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TeleopStatus(null);
    if (msg.topics !== undefined) {
      resolved.topics = msg.topics;
    }
    else {
      resolved.topics = []
    }

    if (msg.fail !== undefined) {
      resolved.fail = msg.fail;
    }
    else {
      resolved.fail = false
    }

    if (msg.quit !== undefined) {
      resolved.quit = msg.quit;
    }
    else {
      resolved.quit = false
    }

    return resolved;
    }
};

module.exports = TeleopStatus;
