// Auto-generated. Do not edit!

// (in-package data_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ArmControlStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.over_limit = null;
    }
    else {
      if (initObj.hasOwnProperty('over_limit')) {
        this.over_limit = initObj.over_limit
      }
      else {
        this.over_limit = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ArmControlStatus
    // Serialize message field [over_limit]
    bufferOffset = _serializer.bool(obj.over_limit, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ArmControlStatus
    let len;
    let data = new ArmControlStatus(null);
    // Deserialize message field [over_limit]
    data.over_limit = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'data_msgs/ArmControlStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0ba76bb194c19513549959891595dcfb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool over_limit
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ArmControlStatus(null);
    if (msg.over_limit !== undefined) {
      resolved.over_limit = msg.over_limit;
    }
    else {
      resolved.over_limit = false
    }

    return resolved;
    }
};

module.exports = ArmControlStatus;
