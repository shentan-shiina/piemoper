// Auto-generated. Do not edit!

// (in-package data_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class CaptureStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.topics = null;
      this.count_in_seconds = null;
      this.frequencies = null;
      this.fail = null;
      this.quit = null;
    }
    else {
      if (initObj.hasOwnProperty('topics')) {
        this.topics = initObj.topics
      }
      else {
        this.topics = [];
      }
      if (initObj.hasOwnProperty('count_in_seconds')) {
        this.count_in_seconds = initObj.count_in_seconds
      }
      else {
        this.count_in_seconds = [];
      }
      if (initObj.hasOwnProperty('frequencies')) {
        this.frequencies = initObj.frequencies
      }
      else {
        this.frequencies = [];
      }
      if (initObj.hasOwnProperty('fail')) {
        this.fail = initObj.fail
      }
      else {
        this.fail = false;
      }
      if (initObj.hasOwnProperty('quit')) {
        this.quit = initObj.quit
      }
      else {
        this.quit = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CaptureStatus
    // Serialize message field [topics]
    bufferOffset = _arraySerializer.string(obj.topics, buffer, bufferOffset, null);
    // Serialize message field [count_in_seconds]
    bufferOffset = _arraySerializer.int32(obj.count_in_seconds, buffer, bufferOffset, null);
    // Serialize message field [frequencies]
    bufferOffset = _arraySerializer.float32(obj.frequencies, buffer, bufferOffset, null);
    // Serialize message field [fail]
    bufferOffset = _serializer.bool(obj.fail, buffer, bufferOffset);
    // Serialize message field [quit]
    bufferOffset = _serializer.bool(obj.quit, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CaptureStatus
    let len;
    let data = new CaptureStatus(null);
    // Deserialize message field [topics]
    data.topics = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [count_in_seconds]
    data.count_in_seconds = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [frequencies]
    data.frequencies = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [fail]
    data.fail = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [quit]
    data.quit = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.topics.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 4 * object.count_in_seconds.length;
    length += 4 * object.frequencies.length;
    return length + 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'data_msgs/CaptureStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e5c23206865129c57d93ad9a543c5903';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] topics
    int32[] count_in_seconds
    float32[] frequencies
    bool fail
    bool quit
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CaptureStatus(null);
    if (msg.topics !== undefined) {
      resolved.topics = msg.topics;
    }
    else {
      resolved.topics = []
    }

    if (msg.count_in_seconds !== undefined) {
      resolved.count_in_seconds = msg.count_in_seconds;
    }
    else {
      resolved.count_in_seconds = []
    }

    if (msg.frequencies !== undefined) {
      resolved.frequencies = msg.frequencies;
    }
    else {
      resolved.frequencies = []
    }

    if (msg.fail !== undefined) {
      resolved.fail = msg.fail;
    }
    else {
      resolved.fail = false
    }

    if (msg.quit !== undefined) {
      resolved.quit = msg.quit;
    }
    else {
      resolved.quit = false
    }

    return resolved;
    }
};

module.exports = CaptureStatus;
