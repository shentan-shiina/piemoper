// Auto-generated. Do not edit!

// (in-package data_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class CaptureServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.start = null;
      this.end = null;
      this.episode_index = null;
      this.dataset_dir = null;
      this.instructions = null;
    }
    else {
      if (initObj.hasOwnProperty('start')) {
        this.start = initObj.start
      }
      else {
        this.start = false;
      }
      if (initObj.hasOwnProperty('end')) {
        this.end = initObj.end
      }
      else {
        this.end = false;
      }
      if (initObj.hasOwnProperty('episode_index')) {
        this.episode_index = initObj.episode_index
      }
      else {
        this.episode_index = 0;
      }
      if (initObj.hasOwnProperty('dataset_dir')) {
        this.dataset_dir = initObj.dataset_dir
      }
      else {
        this.dataset_dir = '';
      }
      if (initObj.hasOwnProperty('instructions')) {
        this.instructions = initObj.instructions
      }
      else {
        this.instructions = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CaptureServiceRequest
    // Serialize message field [start]
    bufferOffset = _serializer.bool(obj.start, buffer, bufferOffset);
    // Serialize message field [end]
    bufferOffset = _serializer.bool(obj.end, buffer, bufferOffset);
    // Serialize message field [episode_index]
    bufferOffset = _serializer.int32(obj.episode_index, buffer, bufferOffset);
    // Serialize message field [dataset_dir]
    bufferOffset = _serializer.string(obj.dataset_dir, buffer, bufferOffset);
    // Serialize message field [instructions]
    bufferOffset = _serializer.string(obj.instructions, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CaptureServiceRequest
    let len;
    let data = new CaptureServiceRequest(null);
    // Deserialize message field [start]
    data.start = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [end]
    data.end = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [episode_index]
    data.episode_index = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [dataset_dir]
    data.dataset_dir = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [instructions]
    data.instructions = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.dataset_dir);
    length += _getByteLength(object.instructions);
    return length + 14;
  }

  static datatype() {
    // Returns string type for a service object
    return 'data_msgs/CaptureServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8bc72a96001878e200ba44235b65bff0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool start
    bool end
    int32 episode_index
    string dataset_dir
    string instructions
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CaptureServiceRequest(null);
    if (msg.start !== undefined) {
      resolved.start = msg.start;
    }
    else {
      resolved.start = false
    }

    if (msg.end !== undefined) {
      resolved.end = msg.end;
    }
    else {
      resolved.end = false
    }

    if (msg.episode_index !== undefined) {
      resolved.episode_index = msg.episode_index;
    }
    else {
      resolved.episode_index = 0
    }

    if (msg.dataset_dir !== undefined) {
      resolved.dataset_dir = msg.dataset_dir;
    }
    else {
      resolved.dataset_dir = ''
    }

    if (msg.instructions !== undefined) {
      resolved.instructions = msg.instructions;
    }
    else {
      resolved.instructions = ''
    }

    return resolved;
    }
};

class CaptureServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CaptureServiceResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CaptureServiceResponse
    let len;
    let data = new CaptureServiceResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'data_msgs/CaptureServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CaptureServiceResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: CaptureServiceRequest,
  Response: CaptureServiceResponse,
  md5sum() { return 'f2a03cd7a3139aa71644d200951dd3dc'; },
  datatype() { return 'data_msgs/CaptureService'; }
};
